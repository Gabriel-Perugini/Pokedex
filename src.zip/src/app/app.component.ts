import { Component } from '@angular/core';
import { Pokemon } from 'src/modules/pokemon';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pokedex';
  logo = "../assets/logo.png";
  imgProfile: String = "../assets/imgProfile.png";
  links: String[] = ['Home', 'Pokedex', 'Video Game', 'Card Games', 'Eventos'];
  pokemons: Pokemon[] = [
    new Pokemon(1, 'Pikachu', ['Eletrico'], 'Pikachu é um tipo de Pokémon elétrico os bolsos em suas bochechas, identificado por discos vermelhos que decoram, são capazes de gerar choques elétricos de intensidade variável, chegando até o nível de poder de um raio. Eles também o usam para se defender.', '../assets/pikachu.png'),
    new Pokemon(2, 'Bulbassauro', ['Grama', 'Veneno'], 'Bulbasaur é um Pokémon bonito nascido com uma grande semente solidamente fixado à sua volta, a semente cresce em tamanho como o Pokémon tem.', '../assets/Bulbasaur.webp'),
    new Pokemon(3, 'Charmander', ['Fogo'], 'A chama que arde na ponta da cauda é uma indicação das suas emoções. A chama vacila quando Charmander está desfrutando de si mesmo. Se o Pokémon fica furioso, a chama queima ferozmente.', '../assets/charmander.png'),
    new Pokemon(4, 'Gengar', ['Fantasma', 'Veneno'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(5, 'Mimikyu', ['Fantasma', 'Fada'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(6, 'Dragapult', ['Fantasma', 'Dragao'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(7, 'Mudkip', ['Agua'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(8, 'Swampert', ['Agua', 'Terra'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(9, 'Torchic', ['Fogo'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(10, 'Blaziken', ['Fogo', 'Lutador'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(11, 'Ratata', ['Normal'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(12, 'Mankey', ['Lutador'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(13, 'Rayquaza', ['Dragao', 'Voador'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(14, 'Groudon', ['Terra'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(15, 'Kyogre', ['Agua'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(16, 'Deoxys', ['Psiquico'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(17, 'Mew', ['Psiquico'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(18, 'Mewtwo', ['Psiquico'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(19, 'Victini', ['Fogo', 'Psiquico'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
    new Pokemon(20, 'Celebi', ['Psiquico', 'Grama'], 'Para roubar a vida do seu alvo, ele se esconde na sombra da presa e espera silenciosamente por uma oportunidade.', '../assets/Gengar.jpg'),
  ];
  selectedPokemon?: Pokemon;

  showDetails(pokemon: Pokemon){
    this.selectedPokemon = pokemon
  }
  closeModal(){
    this.selectedPokemon = undefined;
  }

  filterValue: string= '';
  filteredPokemons(): Pokemon[] {
    if (!this.filterValue){
      return this.pokemons;
    }
    return this.pokemons.filter(pokemon => pokemon.name.toLowerCase().includes(this.filterValue.toLowerCase()));
  }
}


